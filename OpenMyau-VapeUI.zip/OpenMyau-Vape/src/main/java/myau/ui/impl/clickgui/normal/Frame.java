package myau.ui.impl.clickgui.normal;

import lombok.Getter;
import myau.module.Module;
import myau.ui.impl.clickgui.normal.component.Component;
import myau.ui.impl.clickgui.normal.component.ModuleEntry;
import myau.util.RenderUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Frame extends Component {
    private static final int HEADER_H   = 18;
    private static final int CORNER     = 6;
    private static final int SCROLL_W   = 3;
    private static final int MAX_HEIGHT = 200; // max panel body height before scroll kicks in

    private final String categoryName;
    private final ArrayList<ModuleEntry> moduleEntries;
    private int dragX, dragY;
    private boolean dragging;
    private boolean expanded;
    @Getter private float currentHeight;

    // scrolling inside panel
    private float scrollOffset = 0;
    private float targetScroll = 0;

    public Frame(String categoryName, List<Module> modules, int x, int y, int width, int height) {
        super(x, y, width, HEADER_H);
        this.categoryName = categoryName;
        this.dragging = false;
        this.expanded = true;
        this.moduleEntries = new ArrayList<>();
        this.currentHeight = HEADER_H;
        for (Module module : modules) {
            this.moduleEntries.add(new ModuleEntry(module, x, 0, width, 14));
        }
    }

    public boolean isAnyComponentBinding() {
        if (expanded) {
            for (ModuleEntry e : moduleEntries) if (e.isBinding()) return true;
        }
        return false;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset2, float deltaTime) {
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        // smooth internal scroll
        scrollOffset += (targetScroll - scrollOffset) * Math.min(1, deltaTime * 14);

        float listHeight = 0;
        for (ModuleEntry e : moduleEntries) listHeight += e.getCurrentHeight();

        float bodyH   = expanded ? Math.min(listHeight, MAX_HEIGHT) : 0;
        float totalH  = HEADER_H + bodyH;
        this.currentHeight = totalH;

        int sy = y - scrollOffset2;

        RenderUtil.enableRenderState();

        // ── Panel shadow ──────────────────────────────────────────
        int shadowCol = new Color(0, 0, 0, (int)(80 * animationProgress)).getRGB();
        RenderUtil.drawRoundedRect(x + 3, sy + 3, width, totalH, CORNER, shadowCol);

        // ── Panel background ──────────────────────────────────────
        int panelBg = MaterialTheme.getRGBWithAlpha(MaterialTheme.PANEL_BG, alpha);
        RenderUtil.drawRoundedRect(x, sy, width, totalH, CORNER, panelBg);

        // ── Header background ─────────────────────────────────────
        int headerBg = MaterialTheme.getRGBWithAlpha(MaterialTheme.HEADER_BG, alpha);
        boolean bodyOpen = expanded && listHeight > 0;
        RenderUtil.drawRoundedRect(x, sy, width, HEADER_H, CORNER, headerBg,
                true, true, !bodyOpen, !bodyOpen);

        // ── Pink→Yellow gradient accent bar under header ──────────
        int pinkA  = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK,   alpha);
        int yellowA = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_YELLOW, alpha);
        RenderUtil.drawGradientRect(x, sy + HEADER_H - 2, x + width, sy + HEADER_H, pinkA, yellowA);

        // ── Category name ─────────────────────────────────────────
        int textCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_ENABLED, alpha);
        mc.fontRendererObj.drawString(categoryName, x + 6, sy + (HEADER_H - 8) / 2, textCol, false);

        // collapse arrow
        String arrow = expanded ? "-" : "+";
        int arrowW = mc.fontRendererObj.getStringWidth(arrow);
        mc.fontRendererObj.drawString(arrow, x + width - arrowW - 6, sy + (HEADER_H - 8) / 2,
                MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK, alpha), false);

        // ── Module list ───────────────────────────────────────────
        if (expanded && listHeight > 0) {
            RenderUtil.scissor(x, sy + HEADER_H, width, bodyH);

            float currentModuleY = y + HEADER_H - scrollOffset;
            for (int i = 0; i < moduleEntries.size(); i++) {
                ModuleEntry entry = moduleEntries.get(i);
                entry.setX(x);
                entry.setY((int) currentModuleY);
                entry.setWidth(width);
                entry.render(mouseX, mouseY, partialTicks, animationProgress,
                        i == moduleEntries.size() - 1, scrollOffset2, deltaTime);
                currentModuleY += entry.getCurrentHeight();
            }

            RenderUtil.releaseScissor();

            // ── Scrollbar ─────────────────────────────────────────
            if (listHeight > MAX_HEIGHT) {
                float scrollFraction = scrollOffset / (listHeight - MAX_HEIGHT);
                float barH = (bodyH / listHeight) * bodyH;
                float barY = sy + HEADER_H + scrollFraction * (bodyH - barH);

                // track
                int trackCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.SCROLLBAR_BG, alpha);
                RenderUtil.drawRoundedRect(x + width - SCROLL_W - 2, sy + HEADER_H,
                        SCROLL_W, bodyH, SCROLL_W / 2f, trackCol);
                // thumb gradient
                int pinkThumb   = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK,   alpha);
                int yellowThumb = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_YELLOW, alpha);
                RenderUtil.drawGradientRect(
                        x + width - SCROLL_W - 2, (int) barY,
                        x + width - 2,            (int)(barY + barH),
                        pinkThumb, yellowThumb);
            }
        }

        // ── Outer outline ─────────────────────────────────────────
        int outlineCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.SEPARATOR, (int)(alpha * 0.6f));
        RenderUtil.drawRoundedRectOutline(x, sy, width, totalH, CORNER, 0.8f, outlineCol,
                true, true, true, true);

        RenderUtil.disableRenderState();
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset2) {
        render(mouseX, mouseY, partialTicks, animationProgress, isLast, scrollOffset2, 0.016f);
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return mouseClicked(mouseX, mouseY, mouseButton, 0); }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset2) {
        if (isMouseOverHeader(mouseX, mouseY, scrollOffset2)) {
            if (mouseButton == 0) { dragging = true; dragX = mouseX - x; dragY = mouseY - y; return true; }
            if (mouseButton == 1) { expanded = !expanded; return true; }
        }
        if (expanded) {
            // scroll wheel handled in ClickGuiScreen; handle module clicks
            for (ModuleEntry entry : moduleEntries) {
                if (entry.mouseClicked(mouseX, mouseY, mouseButton, scrollOffset2)) return true;
            }
        }
        return false;
    }

    public void scrollPanel(int amount) {
        float listHeight = 0;
        for (ModuleEntry e : moduleEntries) listHeight += e.getCurrentHeight();
        float maxScroll = Math.max(0, listHeight - MAX_HEIGHT);
        targetScroll = Math.max(0, Math.min(maxScroll, targetScroll + amount));
    }

    public boolean isMouseOverPanel(int mouseX, int mouseY, int scrollOffset2) {
        int sy = y - scrollOffset2;
        return mouseX >= x && mouseX <= x + width && mouseY >= sy && mouseY <= sy + currentHeight;
    }

    public boolean isMouseOverHeader(int mouseX, int mouseY, int scrollOffset2) {
        int sy = y - scrollOffset2;
        return mouseX >= x && mouseX <= x + width && mouseY >= sy && mouseY <= sy + HEADER_H;
    }

    @Override public void mouseReleased(int mouseX, int mouseY, int mouseButton) { mouseReleased(mouseX, mouseY, mouseButton, 0); }
    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton, int scrollOffset2) {
        dragging = false;
        if (expanded) for (ModuleEntry e : moduleEntries) e.mouseReleased(mouseX, mouseY, mouseButton, scrollOffset2);
    }

    public void updatePosition(int mouseX, int mouseY) {
        if (dragging) { x = mouseX - dragX; y = mouseY - dragY; }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (expanded) for (ModuleEntry e : moduleEntries) e.keyTyped(typedChar, keyCode);
    }
}
