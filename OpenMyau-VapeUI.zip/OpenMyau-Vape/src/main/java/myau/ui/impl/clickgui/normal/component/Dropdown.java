package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.property.properties.ModeProperty;
import myau.ui.impl.clickgui.normal.MaterialTheme;
import myau.util.RenderUtil;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class Dropdown extends Component {
    private static final int ITEM_H = 13;
    @Getter private final ModeProperty modeProperty;
    private final int headerHeight;
    private boolean expanded;

    public Dropdown(ModeProperty modeProperty, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.modeProperty = modeProperty;
        this.headerHeight = height;
    }

    @Override public int getHeight() {
        List<String> modes = Arrays.asList(modeProperty.getValuePrompt().split(", "));
        return expanded ? headerHeight + modes.size() * ITEM_H : headerHeight;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!modeProperty.isVisible()) return;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        int sy = y - scrollOffset;
        int textCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_DISABLED, alpha);
        int accentCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_YELLOW, alpha);

        mc.fontRendererObj.drawString(modeProperty.getName() + ":", x + 1, sy + (headerHeight - 8) / 2, textCol, false);
        mc.fontRendererObj.drawString(modeProperty.getModeString(), x + width - mc.fontRendererObj.getStringWidth(modeProperty.getModeString()) - 10, sy + (headerHeight - 8) / 2, accentCol, false);
        mc.fontRendererObj.drawString(expanded ? "^" : "v", x + width - 8, sy + (headerHeight - 8) / 2, textCol, false);

        if (expanded) {
            List<String> modes = Arrays.asList(modeProperty.getValuePrompt().split(", "));
            int bgCol = new Color(12, 12, 20, (int)(200*animationProgress)).getRGB();
            RenderUtil.drawRect(x, sy + headerHeight, x + width, sy + headerHeight + modes.size() * ITEM_H, bgCol);
            for (int i = 0; i < modes.size(); i++) {
                int itemY = sy + headerHeight + i * ITEM_H;
                boolean hov = mouseX>=x && mouseX<=x+width && mouseY>=itemY && mouseY<itemY+ITEM_H;
                int col = hov ? MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK, alpha)
                              : MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_DISABLED, alpha);
                mc.fontRendererObj.drawString("  " + modes.get(i), x + 1, itemY + (ITEM_H - 8) / 2, col, false);
            }
        }
    }

    @Override public boolean mouseClicked(int mx,int my,int mb){return false;}
    @Override public boolean mouseClicked(int mx,int my,int mb,int so){
        int sy=y-so;
        if(mx>=x&&mx<=x+width&&my>=sy&&my<=sy+headerHeight){expanded=!expanded;return true;}
        if(expanded){
            List<String> modes=Arrays.asList(modeProperty.getValuePrompt().split(", "));
            for(int i=0;i<modes.size();i++){
                int itemY=sy+headerHeight+i*ITEM_H;
                if(mx>=x&&mx<=x+width&&my>=itemY&&my<itemY+ITEM_H){modeProperty.setValue(i);expanded=false;return true;}
            }
        }
        return false;
    }
    @Override public void mouseReleased(int mx,int my,int mb){}
    @Override public void keyTyped(char t,int k){}
}
