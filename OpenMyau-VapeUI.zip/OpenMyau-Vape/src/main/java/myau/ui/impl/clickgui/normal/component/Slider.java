package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.property.Property;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.PercentProperty;
import myau.ui.impl.clickgui.normal.MaterialTheme;
import myau.util.RenderUtil;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Slider extends Component {
    @Getter private final Property property;
    private final double min, max, step;
    private boolean dragging;

    public Slider(Property property, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.property = property;
        if (property instanceof IntProperty) {
            min = ((IntProperty) property).getMinimum(); max = ((IntProperty) property).getMaximum(); step = 1;
        } else if (property instanceof PercentProperty) {
            min = 0; max = 100; step = 1;
        } else {
            min = ((FloatProperty) property).getMinimum(); max = ((FloatProperty) property).getMaximum(); step = 0.05;
        }
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!property.isVisible()) return;
        if (dragging) { if (Mouse.isButtonDown(0)) update(mouseX); else dragging = false; }

        double value, mn, mx;
        if (property instanceof IntProperty) { mn=((IntProperty)property).getMinimum(); mx=((IntProperty)property).getMaximum(); value=(Integer)property.getValue(); }
        else if (property instanceof PercentProperty) { mn=0; mx=100; value=(Integer)property.getValue(); }
        else { mn=((FloatProperty)property).getMinimum(); mx=((FloatProperty)property).getMaximum(); value=(Float)property.getValue(); }
        double fill = mx-mn!=0 ? Math.max(0,Math.min(1,(value-mn)/(mx-mn))) : 0;

        int sy = y - scrollOffset;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        // label + value
        String label = property.getName();
        String valStr = round(value) + (property instanceof PercentProperty ? "%" : "");
        int textCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_DISABLED, alpha);
        mc.fontRendererObj.drawString(label, x + 1, sy + 1, textCol, false);
        mc.fontRendererObj.drawString(valStr, x + width - mc.fontRendererObj.getStringWidth(valStr) - 1, sy + 1, textCol, false);

        // track background
        int trackY = sy + height - 6;
        int trackX = x + 1;
        int trackW = width - 2;
        int trackCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.SLIDER_TRACK, alpha);
        RenderUtil.drawRoundedRect(trackX, trackY, trackW, 4, 2f, trackCol);

        // filled part: pink→yellow gradient
        int fillW = (int)(trackW * fill);
        if (fillW > 1) {
            int pinkA   = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK,   alpha);
            int yellowA = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_YELLOW, alpha);
            RenderUtil.drawGradientRect(trackX, trackY, trackX + fillW, trackY + 4, pinkA, yellowA);
        }

        // knob
        if (fillW > 0) {
            int knobCol = new Color(255,255,255,alpha).getRGB();
            RenderUtil.drawRoundedRect(trackX + fillW - 3, trackY - 2, 6, 8, 3f, knobCol);
        }
    }

    private void update(int mx) {
        double progress = Math.max(0, Math.min(1, (mx - (x+1)) / (double)(width-2)));
        double v = min + (max-min)*progress;
        if (property instanceof IntProperty || property instanceof PercentProperty) { property.setValue((int)Math.round(v)); }
        else { v = Math.round(v/step)*step; property.setValue((float)Math.max(min,Math.min(max,new BigDecimal(v).setScale(2,RoundingMode.HALF_UP).doubleValue()))); }
    }
    private double round(double v) { return new BigDecimal(v).setScale(2,RoundingMode.HALF_UP).doubleValue(); }

    @Override public boolean mouseClicked(int mx, int my, int mb) { return false; }
    @Override public boolean mouseClicked(int mx, int my, int mb, int so) {
        int sy = y - so;
        if (mb==0 && mx>=x && mx<=x+width && my>=sy+height-9 && my<=sy+height) { dragging=true; update(mx); return true; }
        return false;
    }
    @Override public void mouseReleased(int mx,int my,int mb){dragging=false;}
    @Override public void mouseReleased(int mx,int my,int mb,int so){dragging=false;}
    @Override public void keyTyped(char t,int k){}
}
