package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.Myau;
import myau.module.Module;
import myau.property.Property;
import myau.property.properties.*;
import myau.ui.impl.clickgui.normal.MaterialTheme;
import myau.util.RenderUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleEntry extends Component {
    private static final int ENTRY_H = 14;
    private static final int CORNER  = 4;

    @Getter private final Module module;
    private final List<Component> propertiesComponents;
    private boolean expanded;
    private float currentSettingsHeight = 0f;
    private float hoverAnim = 0f;

    public ModuleEntry(Module module, int x, int y, int width, int height) {
        super(x, y, width, ENTRY_H);
        this.module = module;
        this.expanded = false;
        this.propertiesComponents = new ArrayList<>();
        initializePropertiesComponents();
    }

    private void initializePropertiesComponents() {
        propertiesComponents.add(new KeybindComponent(module, x, y + ENTRY_H, width, 13));
        if (Myau.propertyManager != null) {
            List<Property<?>> props = Myau.propertyManager.properties.get(module.getClass());
            if (props != null) {
                for (Property<?> p : props) {
                    Component c = null;
                    if      (p instanceof BooleanProperty) c = new Switch((BooleanProperty) p, x, 0, width, 13);
                    else if (p instanceof IntProperty || p instanceof FloatProperty || p instanceof PercentProperty)
                                                           c = new Slider(p, x, 0, width, 20);
                    else if (p instanceof ModeProperty)    c = new Dropdown((ModeProperty) p, x, 0, width, 13);
                    else if (p instanceof ColorProperty)   c = new ColorPicker((ColorProperty) p, x, 0, width, 50);
                    else if (p instanceof TextProperty)    c = new TextField((TextProperty) p, x, 0, width, 13);
                    if (c != null) propertiesComponents.add(c);
                }
            }
        }
    }

    private boolean isVisible(Component c) {
        if (c instanceof Switch)      return ((Switch)      c).getProperty().isVisible();
        if (c instanceof Slider)      return ((Slider)      c).getProperty().isVisible();
        if (c instanceof Dropdown)    return ((Dropdown)    c).getModeProperty().isVisible();
        if (c instanceof ColorPicker) return ((ColorPicker) c).getProperty().isVisible();
        if (c instanceof TextField)   return ((TextField)   c).getProperty().isVisible();
        return true;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        int sy = y - scrollOffset;
        boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= sy && mouseY <= sy + ENTRY_H;

        // smooth hover animation
        float hoverTarget = hovered ? 1f : 0f;
        hoverAnim += (hoverTarget - hoverAnim) * Math.min(1, deltaTime * 12);

        // hover background
        if (hoverAnim > 0.01f) {
            int hoverCol = new Color(255, 182, 210, (int)(35 * hoverAnim * animationProgress)).getRGB();
            RenderUtil.drawRoundedRect(x + 2, sy, width - 4, ENTRY_H, CORNER, hoverCol);
        }

        // enabled indicator: pink dot
        if (module.isEnabled()) {
            int dotCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK, alpha);
            RenderUtil.drawRoundedRect(x + 5, sy + ENTRY_H / 2f - 2, 4, 4, 2f, dotCol);
        }

        // module name text
        Color textCol = module.isEnabled() ? MaterialTheme.TEXT_ENABLED : MaterialTheme.TEXT_DISABLED;
        int finalCol = MaterialTheme.getRGBWithAlpha(textCol, alpha);
        mc.fontRendererObj.drawString(module.getName(), x + 13, sy + (ENTRY_H - 8) / 2, finalCol, false);

        // settings expand indicator (small chevron)
        if (!propertiesComponents.isEmpty()) {
            String chevron = expanded ? "^" : "v";
            int chevCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_YELLOW, (int)(alpha * 0.7f));
            mc.fontRendererObj.drawString(chevron, x + width - 10, sy + (ENTRY_H - 8) / 2, chevCol, false);
        }

        // settings panel
        float visH = 0;
        if (expanded) for (Component c : propertiesComponents) if (isVisible(c)) visH += c.getHeight();
        currentSettingsHeight = visH;

        if (currentSettingsHeight > 0.5f) {
            // subtle settings bg
            int settingsBg = new Color(10, 10, 18, (int)(180 * animationProgress)).getRGB();
            RenderUtil.drawRect(x, sy + ENTRY_H, x + width, sy + ENTRY_H + currentSettingsHeight, settingsBg);

            // left accent line
            int lineCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK, (int)(alpha * 0.5f));
            RenderUtil.drawRect(x, sy + ENTRY_H, x + 2, sy + ENTRY_H + currentSettingsHeight, lineCol);

            RenderUtil.scissor(x, sy + ENTRY_H, width, currentSettingsHeight);
            float dynY = y + ENTRY_H;
            for (Component c : propertiesComponents) {
                if (!isVisible(c)) continue;
                c.setX(x + 4);
                c.setY((int) dynY);
                c.setWidth(width - 8);
                c.render(mouseX, mouseY, partialTicks, animationProgress, false, scrollOffset, deltaTime);
                dynY += c.getHeight();
            }
            RenderUtil.releaseScissor();
        }
    }

    public float getCurrentHeight() { return ENTRY_H + currentSettingsHeight; }

    private boolean overHeader(int mx, int my, int scrollOffset) {
        int sy = y - scrollOffset;
        return mx >= x && mx <= x + width && my >= sy && my <= sy + ENTRY_H;
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return false; }
    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        if (overHeader(mouseX, mouseY, scrollOffset)) {
            if (mouseButton == 0) { module.toggle(); return true; }
            if (mouseButton == 1) { if (!propertiesComponents.isEmpty()) expanded = !expanded; return true; }
        }
        if (expanded && currentSettingsHeight >= 5) {
            for (Component c : propertiesComponents) {
                if (!isVisible(c)) continue;
                if (c.mouseClicked(mouseX, mouseY, mouseButton, scrollOffset)) return true;
            }
        }
        return false;
    }

    public boolean isBinding() {
        if (expanded) for (Component c : propertiesComponents)
            if (!isVisible(c)) { continue; }
            else if (c instanceof KeybindComponent && ((KeybindComponent) c).isBinding()) return true;
        return false;
    }

    @Override public void keyTyped(char t, int k) { if (expanded) for (Component c : propertiesComponents) if (isVisible(c)) c.keyTyped(t, k); }
    @Override public void mouseReleased(int mx, int my, int mb) {}
    @Override public void mouseReleased(int mx, int my, int mb, int so) { if (expanded) for (Component c : propertiesComponents) if (isVisible(c)) c.mouseReleased(mx, my, mb, so); }
}
