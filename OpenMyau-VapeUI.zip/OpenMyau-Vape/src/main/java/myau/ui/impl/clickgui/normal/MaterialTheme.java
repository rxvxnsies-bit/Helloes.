package myau.ui.impl.clickgui.normal;

import java.awt.*;

public class MaterialTheme {
    // Prestige-style colours
    public static final Color PANEL_BG         = new Color(18, 18, 24, 235);
    public static final Color HEADER_BG        = new Color(28, 28, 38, 245);
    public static final Color ACCENT_PINK      = new Color(255, 182, 210);   // light pink
    public static final Color ACCENT_YELLOW    = new Color(255, 240, 140);   // light yellow
    public static final Color TEXT_ENABLED     = new Color(255, 255, 255);
    public static final Color TEXT_DISABLED    = new Color(140, 140, 155);
    public static final Color TEXT_COLOR_SECONDARY = new Color(160, 160, 175);
    public static final Color SEPARATOR        = new Color(60, 60, 80, 180);
    public static final Color HOVER_BG         = new Color(255, 182, 210, 30);
    public static final Color SLIDER_TRACK     = new Color(45, 45, 60);
    public static final Color SCROLLBAR_BG     = new Color(35, 35, 50, 180);

    // keep for compat
    public static final Color PRIMARY_COLOR          = ACCENT_PINK;
    public static final Color SURFACE_CONTAINER_HIGH = new Color(40, 40, 55, 200);
    public static final Color TEXT_COLOR             = TEXT_ENABLED;
    public static final Color OUTLINE_COLOR          = SEPARATOR;
    public static final float CORNER_RADIUS_FRAME    = 6.0f;

    public static int getRGB(Color color) { return color.getRGB(); }
    public static int getRGBWithAlpha(Color color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }

    /** Pink → Yellow horizontal gradient, left to right across width w */
    public static int gradientColor(float x, float panelX, float w) {
        float t = Math.max(0, Math.min(1, (x - panelX) / w));
        int r = (int)(ACCENT_PINK.getRed()   + t * (ACCENT_YELLOW.getRed()   - ACCENT_PINK.getRed()));
        int g = (int)(ACCENT_PINK.getGreen() + t * (ACCENT_YELLOW.getGreen() - ACCENT_PINK.getGreen()));
        int b = (int)(ACCENT_PINK.getBlue()  + t * (ACCENT_YELLOW.getBlue()  - ACCENT_PINK.getBlue()));
        return new Color(r, g, b).getRGB();
    }
}
