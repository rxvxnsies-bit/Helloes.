package myau.ui.impl.clickgui.normal.component;

import myau.property.properties.BooleanProperty;
import myau.ui.impl.clickgui.normal.MaterialTheme;
import myau.util.RenderUtil;

import java.awt.*;

public class Switch extends Component {
    private final BooleanProperty booleanProperty;
    private float toggleAnim = 0f;

    public Switch(BooleanProperty booleanProperty, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.booleanProperty = booleanProperty;
        this.toggleAnim = booleanProperty.getValue() ? 1f : 0f;
    }

    public BooleanProperty getProperty() { return booleanProperty; }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!booleanProperty.isVisible()) return;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        float target = booleanProperty.getValue() ? 1f : 0f;
        toggleAnim += (target - toggleAnim) * Math.min(1, deltaTime * 14);

        int sy = y - scrollOffset;
        int textCol = MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_DISABLED, alpha);
        mc.fontRendererObj.drawString(booleanProperty.getName(), x + 1, sy + (height - 8) / 2, textCol, false);

        // mini pill toggle
        int pillW = 24, pillH = 10;
        int pillX = x + width - pillW - 2;
        int pillY = sy + (height - pillH) / 2;

        int offCol = new Color(50, 50, 65, alpha).getRGB();
        int onCol  = MaterialTheme.getRGBWithAlpha(MaterialTheme.ACCENT_PINK, alpha);
        int pillCol = blendColor(offCol, onCol, toggleAnim);
        RenderUtil.drawRoundedRect(pillX, pillY, pillW, pillH, pillH / 2f, pillCol);

        // knob
        int knobX = (int)(pillX + 1 + toggleAnim * (pillW - pillH));
        RenderUtil.drawRoundedRect(knobX, pillY + 1, pillH - 2, pillH - 2, (pillH-2)/2f, new Color(255,255,255,alpha).getRGB());
    }

    private int blendColor(int a, int b, float t) {
        int ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF, aa=(a>>24)&0xFF;
        int br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF, ba=(b>>24)&0xFF;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }

    @Override public boolean mouseClicked(int mx,int my,int mb){return false;}
    @Override public boolean mouseClicked(int mx,int my,int mb,int so){
        int sy=y-so;
        if(mx>=x&&mx<=x+width&&my>=sy&&my<=sy+height){booleanProperty.setValue(!booleanProperty.getValue());return true;}
        return false;
    }
    @Override public void mouseReleased(int mx,int my,int mb){}
    @Override public void keyTyped(char t,int k){}
}
